const chatWindow = document.getElementById("chat-window");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");


const API_KEY = "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";
const MODEL = "mistralai/Mistral-7B-Instruct-v0.1"; 

sendBtn.addEventListener("click", handleUserMessage);
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") handleUserMessage();
});

function addMessage(content, className) {
  const message = document.createElement("div");
  message.className = `message ${className}`;
  message.textContent = content;
  chatWindow.appendChild(message);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function addTypingIndicator() {
  const typing = document.createElement("div");
  typing.id = "typing";
  typing.className = "message bot typing";
  typing.textContent = "ChatGPT is typing...";
  chatWindow.appendChild(typing);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function removeTypingIndicator() {
  const typing = document.getElementById("typing");
  if (typing) typing.remove();
}

async function fetchBotReply(message) {
  if (API_KEY === "YOUR_HUGGING_FACE_API_KEY") {
    // Simulate response for testing
    await new Promise((res) => setTimeout(res, 1500));
    return "This is a simulated response. Add your API key for real answers.";
  }

  try {
    const res = await fetch(`https://api-inference.huggingface.co/models/${MODEL}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: message,
      }),
    });

    const data = await res.json();

    // Some models return an array, some return a string.
    if (Array.isArray(data) && data[0]?.generated_text) {
      return data[0].generated_text;
    }

    // Some models return directly
    if (data.generated_text) {
      return data.generated_text;
    }

    return "Sorry, I didn't understand that.";
  } catch (err) {
    console.error("API error:", err);
    return "Oops! Could not fetch response.";
  }
}

async function handleUserMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  addMessage(message, "user");
  userInput.value = "";

  addTypingIndicator();

  const reply = await fetchBotReply(message);

  removeTypingIndicator();
  addMessage(reply, "bot");
}
