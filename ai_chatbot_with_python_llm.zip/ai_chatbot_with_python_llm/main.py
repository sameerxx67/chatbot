from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from llama_cpp import Llama
import os

# Load the model once
MODEL_PATH = "model/your-model.gguf"

llm = Llama(model_path=MODEL_PATH, n_ctx=2048, verbose=False)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/chat")
async def chat(request: Request):
    data = await request.json()
    prompt = data.get("message", "")

    if not prompt:
        return {"response": "No message received."}

    full_prompt = f"[INST] {prompt} [/INST]"
    output = llm(full_prompt, max_tokens=200, stop=["</s>"])
    return {"response": output["choices"][0]["text"].strip()}
