const chatWindow = document.getElementById("chat-window");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");

sendBtn.addEventListener("click", handleUserMessage);
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") handleUserMessage();
});

function addMessage(content, className) {
  const message = document.createElement("div");
  message.className = `message ${className}`;
  message.textContent = content;
  chatWindow.appendChild(message);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function addTypingIndicator() {
  const typing = document.createElement("div");
  typing.id = "typing";
  typing.className = "message bot typing";
  typing.textContent = "ChatGPT is typing...";
  chatWindow.appendChild(typing);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function removeTypingIndicator() {
  const typing = document.getElementById("typing");
  if (typing) typing.remove();
}

async function fetchBotReply(message) {
  try {
    const res = await fetch("http://127.0.0.1:8000/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ message })
    });

    const data = await res.json();
    return data.response || "Sorry, I didn't get that.";
  } catch (error) {
    console.error("Backend error:", error);
    return "Error reaching the backend.";
  }
}

async function handleUserMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  addMessage(message, "user");
  userInput.value = "";

  addTypingIndicator();

  const reply = await fetchBotReply(message);

  removeTypingIndicator();
  addMessage(reply, "bot");
}
